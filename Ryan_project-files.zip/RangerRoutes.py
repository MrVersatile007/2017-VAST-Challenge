import csv
import pandas


# CSV Input and output paths. Change these.
IN_CSV_PATH = ""
OUT_CSV_PATH = ""


def main():
    # Read in data
    df = pandas.read_csv(IN_CSV_PATH)

    # Find routes
    ranger_cars_in_park = []
    routes = {}

    # Iterate through rows of data
    for index, row in df.iterrows():
        # Only ranger cars
        if row["car-type"] == "2P":
            # If a car is in the park, add the current gate to its route
            if row["car-id"] in ranger_cars_in_park:
                routes[row["car-id"]].append(row["gate-name"])

            # Whenever a car enters or exits the ranger station, start or stop a route
            if row["gate-name"] == "ranger-base":
                if row["car-id"] not in ranger_cars_in_park:
                    ranger_cars_in_park.append(row["car-id"])
                    routes[row["car-id"]] = ["ranger-base"]
                elif row["car-id"] in ranger_cars_in_park:
                    ranger_cars_in_park.remove(row["car-id"])

    # Find only unique routes
    unique_routes = []
    for idx, route in routes.items():
        if route not in unique_routes:
            unique_routes.append(route)

    # Output to CSV
    with open(OUT_CSV_PATH, 'w', newline='') as csvfile:
        csvreader = csv.writer(csvfile, delimiter=',')
        for route in unique_routes:
            csvreader.writerow(route)


if __name__ == "__main__":
    main()
